=== PROJET COMPILATEUR WHILE VERS JAVASCRIPT ===
=== Compilation, ESIR2, 2017-2018 ===
=== GODBILLOT Faustine, GAUTRAIN Antoine, CHIQUET Basile, ROCHAT Nicolas, DIIARA Mame, LABRUE Gwendal, JEGO Emmanuel ===


=== COMPTE RENDU DE PROJET ===
Ce r�pertoire contient 2 sous-r�pertoires
	- "documentation technique" contient le code source de notre compilateur et un ex�cutable pour compilation sans interface.
		Un fichier README.txt y explique plus en d�tail les classes et packages.	
	- "interface" contient de quoi tester le compilateur via interface web. 
		Un fichier README.txt y explique plus en d�tail la m�thode � suivre.
Il contient en plus de cela le compte rendu de notre projet au format PDF.