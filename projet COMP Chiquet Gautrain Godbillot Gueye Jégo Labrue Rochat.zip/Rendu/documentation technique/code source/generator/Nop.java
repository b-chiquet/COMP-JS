package org.xtext.example.generator;

public class Nop extends Instruction{
	public Nop(){}
	
	public String toString(){
		return "<NOP, _, _, _>";
	}
}
